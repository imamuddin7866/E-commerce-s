# 🛒 E-Commerce Website

## 📌 Description
A simple e-commerce website built using Python Flask. Users can view products, add them to a shopping cart, and see the total bill.

## 🚀 Features
- Product Listing with name, price, and image
- Add to Cart
- View Cart and Total Price
- Built using Flask and session storage

## 🛠️ Technologies
- Python 3
- Flask
- HTML5 + CSS3

## 📂 Folder Structure
```
ecommerce-website/
├── app.py
├── requirements.txt
├── static/
│   └── style.css
├── templates/
│   ├── home.html
│   └── cart.html
```

## ▶️ How to Run
```bash
pip install flask
python app.py
```
Then open `http://127.0.0.1:5000` in your browser.
