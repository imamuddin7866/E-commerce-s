from flask import Flask, render_template, session, redirect, url_for

app = Flask(__name__)
app.secret_key = 'secret_key'

products = [
    {'id': 1, 'name': 'Laptop', 'price': 50000, 'image': 'https://via.placeholder.com/150'},
    {'id': 2, 'name': 'Phone', 'price': 15000, 'image': 'https://via.placeholder.com/150'},
    {'id': 3, 'name': 'Headphones', 'price': 2000, 'image': 'https://via.placeholder.com/150'},
]

@app.route('/')
def home():
    return render_template('home.html', products=products)

@app.route('/add_to_cart/<int:id>')
def add_to_cart(id):
    if 'cart' not in session:
        session['cart'] = []
    session['cart'].append(id)
    return redirect(url_for('home'))

@app.route('/cart')
def cart():
    cart_items = []
    total = 0
    if 'cart' in session:
        for pid in session['cart']:
            product = next((p for p in products if p['id'] == pid), None)
            if product:
                cart_items.append(product)
                total += product['price']
    return render_template('cart.html', cart=cart_items, total=total)

if __name__ == '__main__':
    app.run(debug=True)
